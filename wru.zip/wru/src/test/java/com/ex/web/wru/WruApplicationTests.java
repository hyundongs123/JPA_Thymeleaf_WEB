package com.ex.web.wru;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WruApplicationTests {

	@Test
	void contextLoads() {
	}

}
