package com.ex.web.wru;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WruApplication {

	public static void main(String[] args) {
		SpringApplication.run(WruApplication.class, args);
	}

}
